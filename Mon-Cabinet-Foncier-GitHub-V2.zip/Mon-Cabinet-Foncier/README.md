# Mon Cabinet Foncier

Plateforme professionnelle de gestion et de suivi d'un cabinet foncier.

## Objectif

Mon Cabinet Foncier centralise les activités de la structure dans une seule application.

L'application est conçue autour d'une administration principale dirigée par Maman.

## Principaux modules

- Direction
- Gestion du personnel
- Services
- Postes
- Rôles
- Permissions
- Responsabilités
- Dossiers fonciers
- Documents
- Procédures
- Finances
- Avances sur salaire
- Paie
- Bulletins de salaire
- Signature de réception
- Notifications
- Vidéosurveillance
- Journal d'audit

## Architecture

- GitHub : code source
- Supabase : authentification et base de données
- Vercel : déploiement

## Sécurité

Authentification → Profil → Rôle → Permissions → Espace autorisé → Données autorisées → Journal d'audit.

Aucune clé `service_role` ne doit être placée dans le frontend.

## Activation des employés

1. Maman crée l'employé.
2. Le numéro de téléphone personnel est enregistré.
3. Un code temporaire d'activation est envoyé.
4. L'employé communique le code à Maman.
5. Maman valide l'activation.
6. L'employé configure son compte.
7. L'employé crée lui-même son mot de passe.
8. Le compte devient actif.

Le mot de passe n'est jamais communiqué à Maman.

## Paie

Paie préparée → Paie validée → Paiement enregistré → Bulletin délivré → Réception signée.

La signature confirme la réception et ne modifie pas le montant payé.

## Structure du projet

```
├── public/              Site déployé (dossier servi par Vercel)
│   ├── index.html
│   ├── favicon.svg
│   ├── css/             reset, variables, global, components, responsive
│   ├── js/
│   │   ├── main.js      Point d'entrée
│   │   ├── config/      app.js, supabase.js
│   │   ├── data/        modules.js (liste des modules)
│   │   ├── components/  header, hero, footer, module-card
│   │   ├── views/       dashboard.js
│   │   └── utils/       escape.js
│   └── assets/          logo, icons
├── docs/                DEPLOIEMENT.md
├── .github/workflows/   CI (vérification de syntaxe)
├── package.json
└── vercel.json
```

## Démarrage

```bash
npm run dev
```

Voir [docs/DEPLOIEMENT.md](docs/DEPLOIEMENT.md) pour la publication sur GitHub et Vercel.

## État

Version 1 — architecture initiale.
