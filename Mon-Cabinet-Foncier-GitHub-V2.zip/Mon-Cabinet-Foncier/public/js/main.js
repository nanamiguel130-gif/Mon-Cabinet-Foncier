import { renderDashboard } from "./views/dashboard.js";

renderDashboard(document.getElementById("app"));
