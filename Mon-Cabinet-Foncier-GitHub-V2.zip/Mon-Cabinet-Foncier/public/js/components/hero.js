import { APP_CONFIG } from "../config/app.js";
import { escapeHtml } from "../utils/escape.js";

export function Hero() {
  return `
    <section class="hero">
      <span class="badge">Plateforme professionnelle</span>
      <h1>${escapeHtml(APP_CONFIG.name)}</h1>
      <p>
        Une plateforme centralisée pour piloter les collaborateurs,
        dossiers fonciers, documents, finances, paie et procédures du cabinet.
      </p>
    </section>
  `;
}
