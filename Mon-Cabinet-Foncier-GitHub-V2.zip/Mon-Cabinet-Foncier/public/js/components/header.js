import { APP_CONFIG } from "../config/app.js";
import { escapeHtml } from "../utils/escape.js";

export function Header() {
  return `
    <header class="topbar">
      <div class="brand-container">
        <div class="brand-logo">MC</div>
        <div>
          <div class="brand">${escapeHtml(APP_CONFIG.name)}</div>
          <div class="subtitle">Solution intelligente de gestion foncière</div>
        </div>
      </div>

      <div class="topbar-actions">
        <span class="status-badge">Version ${escapeHtml(APP_CONFIG.version)}</span>
        <button id="logoutBtn" class="btn btn-outline" type="button">
          Déconnexion
        </button>
      </div>
    </header>
  `;
}
