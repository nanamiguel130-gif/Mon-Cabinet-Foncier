import { escapeHtml } from "../utils/escape.js";

export function ModuleCard({ id, icon, title, description }) {
  return `
    <article class="card">
      <div class="card-icon">${icon}</div>
      <h2>${escapeHtml(title)}</h2>
      <p>${escapeHtml(description)}</p>
      <button class="module-button" type="button" data-module="${escapeHtml(id)}" data-title="${escapeHtml(title)}">
        Accéder
      </button>
    </article>
  `;
}
