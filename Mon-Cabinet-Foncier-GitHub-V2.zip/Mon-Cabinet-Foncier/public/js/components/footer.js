import { APP_CONFIG } from "../config/app.js";
import { escapeHtml } from "../utils/escape.js";

export function Footer() {
  return `
    <footer class="footer">
      <span>${escapeHtml(APP_CONFIG.name)}</span>
      <span>© ${new Date().getFullYear()}</span>
    </footer>
  `;
}
