import { MODULES } from "../data/modules.js";
import { Header } from "../components/header.js";
import { Hero } from "../components/hero.js";
import { Footer } from "../components/footer.js";
import { ModuleCard } from "../components/module-card.js";

export function renderDashboard(root) {
  root.innerHTML = `
    <div class="app-shell">
      ${Header()}
      <main class="main-content">
        ${Hero()}
        <section class="dashboard-grid">
          ${MODULES.map(ModuleCard).join("")}
        </section>
      </main>
      ${Footer()}
    </div>
  `;

  root.querySelector("#logoutBtn").addEventListener("click", () => {
    alert("La déconnexion sera connectée à Supabase Auth lors de l'intégration de l'authentification.");
  });

  root.querySelectorAll(".module-button").forEach((button) => {
    button.addEventListener("click", () => {
      alert(`${button.dataset.title} sera activé lors de l'intégration du module correspondant.`);
    });
  });
}
