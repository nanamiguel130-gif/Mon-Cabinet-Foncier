export const APP_CONFIG = {
  name: "Mon Cabinet Foncier",
  version: "1.0.0",
  environment: "development",
  currency: "FCFA",
  defaultLanguage: "fr",
  roles: {
    ADMIN: "admin",
    DIRECTION: "direction",
    RESPONSABLE: "responsable",
    EMPLOYE: "employe"
  },
  payrollStatuses: {
    DRAFT: "draft",
    VALIDATED: "validated",
    PAID: "paid",
    DELIVERED: "delivered",
    SIGNED: "signed"
  },
  activationCodeDurationMinutes: 15,
  sessionTimeoutMinutes: 60
};
