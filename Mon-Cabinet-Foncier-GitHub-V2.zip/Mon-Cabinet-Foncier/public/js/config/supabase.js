/*
 * MON CABINET FONCIER — Configuration Supabase
 *
 * À compléter lorsque le projet Supabase officiel sera créé.
 * Seules l'URL du projet et la clé publique (anon key) sont autorisées ici.
 *
 * NE JAMAIS mettre ici :
 * - service_role
 * - clé secrète
 * - mot de passe
 * - identifiant bancaire
 */

export const SUPABASE_CONFIG = {
  url: "",
  anonKey: ""
};

export default SUPABASE_CONFIG;
