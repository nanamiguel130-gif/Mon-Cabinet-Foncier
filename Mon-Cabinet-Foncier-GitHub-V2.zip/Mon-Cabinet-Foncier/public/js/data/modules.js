/* Liste des modules affichés sur le tableau de bord. */
export const MODULES = [
  { id: "direction", icon: "👩🏾‍💼", title: "Direction", description: "Administration générale, configuration et supervision." },
  { id: "personnel", icon: "👥", title: "Personnel", description: "Gestion des collaborateurs, services, postes et responsabilités." },
  { id: "dossiers", icon: "📁", title: "Dossiers fonciers", description: "Création, suivi et organisation des dossiers." },
  { id: "documents", icon: "📄", title: "Documents", description: "Centralisation et suivi des documents." },
  { id: "finances", icon: "💰", title: "Finances", description: "Suivi des recettes, dépenses, charges et engagements." },
  { id: "avances", icon: "💵", title: "Avances sur salaire", description: "Demandes, validations et suivi des avances." },
  { id: "paie", icon: "🧾", title: "Paie", description: "Préparation, validation et suivi des paiements." },
  { id: "reception-salaires", icon: "✍🏾", title: "Réception des salaires", description: "Bulletins et signatures électroniques de réception." },
  { id: "videosurveillance", icon: "📹", title: "Vidéosurveillance", description: "Gestion des accès aux caméras autorisées." },
  { id: "securite", icon: "🔐", title: "Sécurité", description: "Rôles, permissions, authentification et contrôle d'accès." },
  { id: "notifications", icon: "🔔", title: "Notifications", description: "Alertes et informations importantes." },
  { id: "audit", icon: "📋", title: "Journal d'audit", description: "Traçabilité des opérations importantes." }
];
