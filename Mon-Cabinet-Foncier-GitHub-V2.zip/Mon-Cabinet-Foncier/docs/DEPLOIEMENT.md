# Déploiement

## 1. Publier sur GitHub

Créez d'abord le dépôt sur github.com (de préférence en **privé**), sans README ni .gitignore, puis :

```bash
cd Mon-Cabinet-Foncier
git init -b main
git add .
git commit -m "Version 1 — architecture initiale"
git remote add origin https://github.com/<votre-compte>/mon-cabinet-foncier.git
git push -u origin main
```

## 2. Tester en local

```bash
npm run dev
```

## 3. Déployer sur Vercel

1. Vercel → **Add New… → Project** → importer le dépôt GitHub.
2. Framework Preset : **Other**. Aucune commande de build.
3. Le dossier de sortie `public` est déjà défini dans `vercel.json`.
4. **Deploy**. Chaque `git push` sur `main` redéploie automatiquement.

## 4. Brancher Supabase (plus tard)

Renseigner l'URL et la clé `anon` dans `public/js/config/supabase.js`.
Ne jamais y mettre de clé `service_role`.
